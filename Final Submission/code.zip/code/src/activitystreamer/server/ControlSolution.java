package activitystreamer.server;

import activitystreamer.util.Settings;
import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;
import org.json.simple.JSONObject;
import org.json.simple.parser.JSONParser;
import org.json.simple.parser.ParseException;

import java.io.IOException;
import java.net.Socket;
import java.util.*;
import java.util.Map.Entry;

import javax.net.ssl.SSLSocket;
import javax.net.ssl.SSLSocketFactory;



public class ControlSolution extends Control {
	private static final Logger log = LogManager.getLogger();
	
	/*
	 * additional variables as needed
	 */
	private enum Command{AUTHENTICATE,INVALID_MESSAGE,AUTHENTICATION_FAIL,LOGIN,LOGIN_SUCCESS,
		REDIRECT,LOGIN_FAILED,LOGOUT,ACTIVITY_MESSAGE,SERVER_ANNOUNCE,ACTIVITY_BROADCAST,
		REGISTER,REGISTER_FAILED,REGISTER_SUCCESS,LOCK_REQUEST,LOCK_DENIED,LOCK_ALLOWED,
		CLIENT_CHANGE,REPLY,HELLO,FINISH_HELLO};
		
	private enum ClientOperation{
	        LOGIN,LOGOUT
	    }
	
	private enum Invalid{
        NO_COMMAND_MESSAGE,
        JSON_PARSE_ERROR,
        SERVER_HAD_ALREADY_SUCCESSFULLY_AUTHENTICATED,
        UNAUTHENTICATED_SERVER,
        INCORRECT_MESSAGE,
        CLIENT_ALREADY_LOGINED,
        UNKNOWN_COMMAND
    }
	private static final String ID = Settings.nextSecret();
	private static ArrayList<Connection> serverConnections = new ArrayList<Connection>();
	private static HashMap<String,String> Database = new HashMap<String,String>();
	private static ArrayList<Connection> loginedUsers = new ArrayList<Connection>();
	private static HashMap<String,String> shouldDelete = new HashMap<String,String>();
	private static HashMap<Connection,Integer> connectionInfo = new HashMap<Connection,Integer>();
	private static long endTime;
	private static ArrayList<RegisterRequest> registerRequests = new ArrayList<RegisterRequest>();
	private static Command commandState;
	private static HashMap<String,ServerInfo> serverInfo = new HashMap<String,ServerInfo>();
	private static ArrayList<Connection> SSLConnections = new ArrayList<Connection>();
	private static boolean supportSSL = false;
	private static boolean finishHello = false;
	private static HashMap<Connection, ArrayList<JSONObject>> cache = new HashMap<>();
    private static long lastBroadcastTime = 0;
    private static SSLListener SSLlistener;
    // since control and its subclasses are singleton, we get the singleton this way
	public static ControlSolution getInstance() {
		if(control==null){
			control=new ControlSolution();
		} 
		return (ControlSolution) control;
	}
	
	public ControlSolution() {
		super();
		/*
		 * Do some further initialization here if necessary
		 */
		if(supportSSL){
			try {
				SSLlistener = new SSLListener();
			} catch (IOException e1) {
				log.fatal("failed to startup a listening thread: "+e1);
				System.exit(-1);
			}
		}
		
		// check if we should initiate a connection and do so if necessary
		this.initiateConnection();
		
		
		// start the server's activity loop
		// it will call doActivity every few seconds
		//start();
	}
	
	
	public synchronized Connection incomingSSLConnection(Socket s) throws IOException{
		Connection c = this.incomingConnection(s);
		SSLConnections.add(c);
		return c;
		
	}
	
	
	/*
	 * a new incoming connection
	 */
	@Override
	public Connection incomingConnection(Socket s) throws IOException{
		Connection con = super.incomingConnection(s);
		/*
		 * do additional things here
		 */
		
		return con;
	}
	
	/*
	 * a new outgoing connection
	 */
	@Override
	public Connection outgoingConnection(Socket s) throws IOException{
		Connection con;
		if(!finishHello && supportSSL){
			con = super.outgoingConnection(s);
			hello(con);
		}else{
			
			if(supportSSL){
				
				con = super.outgoingConnection(s);
			}else{
				con = super.outgoingConnection(s);
				
			}
			authenticate(con);
			start();
		}
		
		
		
		
		/*
		 * do additional things here
		 */
		
		//try to authenticate to a system
		//
		return con;
	}
	
	public void initiateSSLConnection(){
		
		
		//Location of the Java keystore file containing the collection of 
		//certificates trusted by this application (trust store).
		//System.setProperty("javax.net.ssl.trustStore", "files/tserver.keystore");
		System.setProperty("javax.net.ssl.keyStore", "files/kserver.keystore");
		//System.setProperty("javax.net.ssl.keyStorePassword", "123456");
		//System.setProperty("javax.net.ssl.trustStorePassword", "123456");
		//System.setProperty("javax.net.debug","all");
		
		//Create SSL socket and connect it to the remote server 
		SSLSocketFactory sslsocketfactory = (SSLSocketFactory) SSLSocketFactory.getDefault();
		//SSLSocket sslsocket = (SSLSocket) sslsocketfactory.createSocket(Settings.getRemoteHostname(), Settings.getRemoteSSLPort());
		// make a connection to another server if remote hostname is supplied
		if(Settings.getRemoteHostname()!=null){
			try {
				outgoingConnection((SSLSocket) sslsocketfactory.createSocket(Settings.getRemoteHostname(), Settings.getRemoteSSLPort()));
			} catch (IOException e) {
				log.error("failed to make SSLconnection to "+Settings.getRemoteHostname()+":"+Settings.getRemotePort()+" :"+e);
				System.exit(-1);
			}
		}else{
			Settings.setSecret(Settings.nextSecret());
			log.info("the secret of the system is : " + Settings.getSecret());
			start();
		}
	}
	
	
	/*
	 * the connection has been closed
	 */
	@Override
	public void connectionClosed(Connection con){
		//con.closeCon();
		super.connectionClosed(con);
		/*
		 * do additional things here
		 */
		//when close a connection, remove it from the record, if it is in it/
		if(serverConnections.contains(con)){
			serverConnections.remove(con);
		}
		if(loginedUsers.contains(con)){
			loginedUsers.remove(con);
		}
		
		if(SSLConnections.contains(con)){
			SSLConnections.remove(con);
		}
	}
	
	
	/*
	 * process incoming msg, from connection con
	 * return true if the connection should be closed, false otherwise
	 */
	@Override
	public synchronized boolean process(Connection con,String msg){
		/*
		 * do additional work here
		 * return true/false as appropriate
		 */
		
		JSONObject obj=new JSONObject();
		JSONParser parser = new JSONParser();
		
		try {
			obj = (JSONObject) parser.parse(msg);
		} catch (ParseException e1) {
			// TODO Auto-generated catch block
			invalidMessage(con,Invalid.JSON_PARSE_ERROR);
			//e1.printStackTrace();
		}
		
		//log.debug(msg);	
		
		String command = (String) obj.get("command");
		try{
			commandState = Command.valueOf(command);
		}catch(Exception e){
			e.printStackTrace();
			if(command == null){
				
				invalidMessage(con,Invalid.NO_COMMAND_MESSAGE);
			}else{
				invalidMessage(con,Invalid.INCORRECT_MESSAGE);
				
			}
		}
		//when a message is sent from a server, check if it is a authenticated server
		switch(commandState){
			case LOCK_DENIED:
			case ACTIVITY_BROADCAST:
			case LOCK_ALLOWED:	
			case LOCK_REQUEST:
			case SERVER_ANNOUNCE:
				if(!serverConnections.contains(con)){
					invalidMessage(con,Invalid.UNAUTHENTICATED_SERVER);
					return true;
				}
				
			default:
				
		}
		log.debug("Receive " + commandState.toString() + " message from " + Settings.socketAddress(con.getSocket()));
		
		if(supportSSL){
			switch(commandState){
			case CLIENT_CHANGE:
				return processClientChange(con,obj);
			case INVALID_MESSAGE:
				if(!finishHello){
					supportSSL = false;
					finishHello = true;
					this.initiateConnection();
					return false;
				}
				break;
			case REPLY:
				return processReply(con,obj);
			case HELLO:
				return processHello(con,obj);
			case FINISH_HELLO:
				return processFinishHello(con,obj);
			}
			
		}
		//process the different message
		switch(commandState){
			case AUTHENTICATE:
				return processAuthenticate(con,obj);
			case LOGIN:
				return processLogin(con,obj);
			case REGISTER:
				return processRegister(con,obj);
			case LOCK_DENIED:
				return processLockDenied(con,obj);
				
			case ACTIVITY_BROADCAST:
				return processActivityBroadcast(con,obj);
			case LOCK_ALLOWED:
				processLockAllowed(con,obj);
				handleRegister();
				return false;
			case ACTIVITY_MESSAGE:
				return processActivityMessage(con,obj);
			case AUTHENTICATION_FAIL:
				return processAuthenticationFail(con,obj);
			case LOCK_REQUEST:
				return processLockRequest(con,obj);
			case INVALID_MESSAGE:
				log.info(obj.get("info"));
				return true;
			case LOGOUT:
				log.info("User logout.");
				if(supportSSL){
					clientChange(ClientOperation.LOGOUT);
				}
				return true;
			case SERVER_ANNOUNCE:
				return processServerAnnounce(con,obj);
			default:
				invalidMessage(con,Invalid.UNKNOWN_COMMAND);
				return true;
		}
	
		
		
		
		
	}

	
	
	/*
	 * Called once every few seconds
	 * Return true if server should shut down, false otherwise
	 */
	@Override
	public boolean doActivity(){
		/*
		 * do additional work here
		 * return true/false as appropriate
		 */
		serverAnnounce();
		return false;
	}
	
	/*
	 * Other methods as needed
	 */
	
	/*
	 * These methods are used to process the incoming message
	 */

	
	private boolean processAuthenticate(Connection con, JSONObject inJSON){
		
		String secret = (String) inJSON.get("secret");
		if(secret == null){
			invalidMessage(con,Invalid.INCORRECT_MESSAGE);
			return true;
		}
		if( serverConnections.contains(con) ){
			invalidMessage(con,Invalid.SERVER_HAD_ALREADY_SUCCESSFULLY_AUTHENTICATED);
			return true;
		}else if(secret.equals(Settings.getSecret())){
			serverConnections.add(con);
			log.info("AUTHENTICATE socket: " + Settings.socketAddress(con.getSocket()) + " successfully");
			return false;
		}else{
			authenticationFail(con,inJSON);
			return true;
		}
		
	}
	
	private boolean processAuthenticationFail(Connection con, JSONObject inJSON){
		
		log.info("Authentication Fail to socket: " +Settings.socketAddress(con.getSocket()));
		//System.exit(0);
		return true;
	}
	
	private boolean processLogin(Connection con,JSONObject inJSON){
		String username = (String) inJSON.get("username");
		String secret = (String) inJSON.get("secret");
		JSONObject outJSON = new JSONObject();
		if(username == null ? true:(((secret == null && !username.equals("anonymous")) || (username.equals("anonymous") && secret != null))) ){
			invalidMessage(con,Invalid.INCORRECT_MESSAGE);
			return true;
		}
			
		if(username.equals("anonymous") || (Database.containsKey(username) ? Database.get(username).equals(secret):false) ){
			outJSON.put("info", "logged in as user " + username);//change
			outJSON.put("command", "LOGIN_SUCCESS");
			log.info("User " + username + " login.");
			log.debug("Send "+ Command.LOGIN_SUCCESS.toString() +" message to " + Settings.socketAddress(con.getSocket()));
			loginedUsers.add(con);
		}else{
			outJSON.put("info", "attempt to login with wrong secret");//change
			outJSON.put("command", "LOGIN_FAILED");
			log.debug("Send "+ Command.LOGIN_FAILED.toString() +" message to " + Settings.socketAddress(con.getSocket()));
		}
				
		
		con.writeMsg(outJSON.toString());
		if(outJSON.get("command").equals("LOGIN_SUCCESS")){
			int serverNum = 0;
			String hostname = null;
			int port = 0;
			int SSLport = 0;
			boolean SSL = false;
			for(Entry<String, ServerInfo> e: serverInfo.entrySet()){
				if((loginedUsers.size() - e.getValue().load) >= 2){
					if(supportSSL){
						if(e.getValue().serverNum > serverNum){
							hostname = e.getValue().hostname;
							port = e.getValue().port;
							serverNum = e.getValue().serverNum;
							SSL = e.getValue().supportSSL;
							SSLport = e.getValue().SSLPort;
						}
					}else{
						hostname = e.getValue().hostname;
						port = e.getValue().port;
						break;
					}
					
				}
			}
			
			if(hostname != null){
				if(SSL){
					redirect(con,hostname,port,SSL,SSLport);
				}else{
					redirect(con,hostname,port);
				}
			}else if(supportSSL){
				clientChange(ClientOperation.LOGIN);
			}
			
			return false;
		}else{
			return true;
		}
		
	}
	
	private boolean processRegister(Connection con,JSONObject inJSON){
		String username = (String) inJSON.get("username");
		String secret = (String) inJSON.get("secret");
		
		if(username == null || secret == null){
			invalidMessage(con,Invalid.INCORRECT_MESSAGE);
			return true;
		}
		if(loginedUsers.contains(con)){
			invalidMessage(con,Invalid.CLIENT_ALREADY_LOGINED);
			return true;
		}else if(!Database.containsKey(username)){
			if(!serverConnections.isEmpty()){
				registerRequests.add(new RegisterRequest(username,secret,System.currentTimeMillis(),con,inJSON));
				inJSON.put("command", "LOCK_REQUEST");
				for(Connection c:serverConnections){
					lockRequest(c,inJSON);
				}
			}else{
				
				registerSuccess(con,inJSON);
			}
			return false;
		}else{
			registerFailed(con,inJSON);
			return true;
		}
		
	}
	
	private boolean processActivityMessage(Connection con, JSONObject inJSON){
		String secret = (String) inJSON.get("secret");
		String username = (String) inJSON.get("username");
		JSONObject activityObj = new JSONObject();
		activityObj = (JSONObject) inJSON.get("activity");
		if(username == null || activityObj == null || (!username.equals("anonymous") && secret == null)){
			invalidMessage(con,Invalid.INCORRECT_MESSAGE);
			return true;
		}
		
		if(loginedUsers.contains(con) ){
			activityObj.put("authenticated_user", username);
			//if(!supportSSL || !SSLConnections.contains(con)){
				//inJSON.put("activity", activityObj);
			//}
			if(!this.getConnections().isEmpty()){
				if(supportSSL){
					activityMessagePacking(con,activityObj);
				}else{
					inJSON.put("activity", activityObj);
					for(Connection c:this.getConnections()){
						if(!SSLConnections.contains(con)){
							activityBroadcast(c,inJSON);
						}
					}
				}
				/*
				
				*/
				
			}
			return false;
		}else{
			authenticationFail(con, inJSON);
			return true;
		}
		
		
		
		
	}
	
	
	private void activityMessagePacking(Connection con,JSONObject activityObj){
		//log.debug("catche the activity");
        if (lastBroadcastTime == 0 || System.currentTimeMillis() - lastBroadcastTime > 5000) {
            for (Connection c : this.getConnections()) {
            	//System.out.println("check "+Settings.socketAddress(c.getSocket()));
                if(loginedUsers.contains(con) || (!c.equals(con)) ){
                    //System.out.println("try to send to "+Settings.socketAddress(c.getSocket()));
                	activityBroadcast(c, activityObj);
                }
            }
            lastBroadcastTime = System.currentTimeMillis();

        } else {

            if (cache.isEmpty()) {

                Timer timer = new Timer();

                TimerTask timerTask = new TimerTask() {
                    @Override
                    public void run() {

                        for (Connection c : ControlSolution.getInstance().getConnections()) {
                        	//if(SSLConnections.contains(c)){
                        		ControlSolution.getInstance().activityBroadcast(c, new JSONObject());
                        	//}
                        }
                        lastBroadcastTime = System.currentTimeMillis();
                        cache.clear();
                        this.cancel();
                    }
                };

                timer.schedule(timerTask, 5000 + lastBroadcastTime-System.currentTimeMillis());
            }

            if (cache.containsKey(con)){
                cache.get(con).add(activityObj);
            }else {
                ArrayList<JSONObject> hashSet = new ArrayList<>();
                hashSet.add(activityObj);
                cache.put(con,hashSet);
            }//store the message into server's cache
        }
    }
	
	private boolean processActivityBroadcast(Connection con, JSONObject inJSON){
		if(supportSSL){
			if(SSLConnections.contains(con)){
				for (Object o : inJSON.keySet()) {
					
					if (o.toString().matches("activity+\\d+")) {
		                JSONObject activityObj = (JSONObject) inJSON.get(o);
		                if (activityObj == null) {
		                    invalidMessage(con, Invalid.INCORRECT_MESSAGE);
		                    return true;
		                }
		                activityMessagePacking(con,activityObj);
		            }
					
				}
			}else{
				if (inJSON.get("activity") == null) {
                    invalidMessage(con, Invalid.INCORRECT_MESSAGE);
                    return true;
                }
                activityMessagePacking(con,(JSONObject) inJSON.get("activity"));
			}
		}else{
			JSONObject activityObj = (JSONObject) inJSON.get("activity");;
			if(activityObj == null){
				invalidMessage(con,Invalid.INCORRECT_MESSAGE);
				return true;
			}
			for(Connection c:this.getConnections()){
				if(!con.equals(c)){
					activityBroadcast(c,inJSON);
				}
			}
		}
		return false;
		
	}
	
		
	private boolean processLockRequest(Connection con, JSONObject inJSON){
		
		String username = (String) inJSON.get("username");
		String secret = (String) inJSON.get("secret");
		
		if(username == null || secret == null){
			invalidMessage(con,Invalid.INCORRECT_MESSAGE);
			return true;
		}
		
		if(!Database.containsKey(username)){
			inJSON.put("command", "LOCK_ALLOWED");
			Database.put(username, secret);
			if(!serverConnections.isEmpty()){
				for(Connection c: serverConnections){
					lockAllowed(c,inJSON);
				}
				
			}
			
		}else{
			if(!Database.get(username).equals(secret)){
				inJSON.put("command", "LOCK_DENIED");
				if(!serverConnections.isEmpty()){
					for(Connection c: serverConnections){
						
						lockDenied(c,inJSON);
					}
					
				}
			}
		}
		
		if(!serverConnections.isEmpty()){
			for(Connection c: serverConnections){
				if(!c.equals(con)){
					lockRequest(c,inJSON);
				}
			}
			
		}
		
		return false;
		
		
		
		
	}
	
	private boolean processLockDenied(Connection con,JSONObject inJSON){
		String username = (String) inJSON.get("username");
		String secret = (String) inJSON.get("secret");
		
		if(username == null || secret == null){
			invalidMessage(con,Invalid.INCORRECT_MESSAGE);
			return true;
		}
		
		if(!registerRequests.isEmpty()){
			ArrayList<RegisterRequest> iter = (ArrayList<RegisterRequest>) registerRequests.clone();
			for(RegisterRequest r:iter){
				if(username.equals(r.username)){
					registerFailed(r.con,r.inJSON);
					r.con.closeCon();
					connectionClosed(r.con);
				}
			}
			handleRegister();
		}else{
			if(Database.containsKey(username) && secret.equals(Database.get(username))){
				Database.remove(username);
			}
		}
		if(!serverConnections.isEmpty()){
			for(Connection c:serverConnections){
				if(!c.equals(con)){
					lockDenied(c,inJSON);
				}
			}
		}
		
		return false;
		
	}

	private boolean processLockAllowed(Connection con, JSONObject inJSON){
		String username = (String) inJSON.get("username");
		String secret = (String) inJSON.get("secret");
		
		if(username == null || secret == null){
			invalidMessage(con,Invalid.INCORRECT_MESSAGE);
			return true;
		}
		
		if(!registerRequests.isEmpty()){
			Iterator<RegisterRequest> iter = registerRequests.iterator();
			while(iter.hasNext()){
				RegisterRequest r =iter.next();
				if(username.equals(r.username) && secret.equals(r.secret)){
					r.responseServer++;
				}
			}
			handleRegister();
		}
		
		if(!serverConnections.isEmpty()){
			for(Connection c:serverConnections){
				if(!c.equals(con)){
					lockAllowed(c,inJSON);
				}
			}
		}
		return false;
	}
	
	private boolean processClientChange(Connection con, JSONObject inJSON){
		ClientOperation CO = ClientOperation.valueOf((String) inJSON.get("client_operation"));
		if(!serverConnections.contains(con)){
			invalidMessage(con,Invalid.UNAUTHENTICATED_SERVER);
			return true;
		}
		if(CO == null){
			invalidMessage(con,Invalid.INCORRECT_MESSAGE);
			return true;
		}
		
		switch(CO){
		case LOGIN:
			
			connectionInfo.put(con, (connectionInfo.get(con) == null? 1:connectionInfo.get(con)+1));
			break;
		case LOGOUT:
			connectionInfo.put(con, connectionInfo.get(con)-1);
			break;
		}
		for(Connection c: serverConnections){
        	if(!con.equals(c) && SSLConnections.contains(con)){
        		c.writeMsg(inJSON.toJSONString());
        	}
        }
		return false;
	}
	
	private boolean processHello(Connection con, JSONObject inJSON){
		
		if(inJSON.get("supportSSL") == null){
			invalidMessage(con,Invalid.INCORRECT_MESSAGE);
			return true;
		}
		boolean ifSupportSSL =(Boolean) inJSON.get("supportSSL");
		if(ifSupportSSL){
			reply(con);
			return false;
		}
		
		return false;
	}
	
	private boolean processReply(Connection con, JSONObject inJSON){
		
		if(inJSON.get("supportSSL") == null || inJSON.get("SSLPort") == null){
			invalidMessage(con,Invalid.INCORRECT_MESSAGE);
			return true;
		}
		Settings.setRemoteSSLPort((int) Integer.valueOf(inJSON.get("SSLPort").toString()));
		boolean ifSupportSSL = (Boolean) inJSON.get("supportSSL");
		finishHello = true;
		if(ifSupportSSL){
			finishHello(con);
			this.initiateSSLConnection();
			return true;
		}else{
			finishHello(con);
			
			this.supportSSL = false;
			return true;
		}
		
	}
	
	private boolean processFinishHello(Connection con, JSONObject inJSON){
		
		return true;
		
		
	}
	
	/*
	 * The following methods are used to send particular message.
	 */
	
	private void authenticate(Connection con){
		JSONObject obj=new JSONObject();
		
		obj.put("secret", Settings.getSecret());//change
		obj.put("command", "AUTHENTICATE");
		serverConnections.add(con);
		SSLConnections.add(con);
		con.writeMsg(obj.toString());
		log.debug("Send "+ Command.AUTHENTICATE.toString() +" message to " + Settings.socketAddress(con.getSocket()));
		
	}
	
	private void authenticationFail(Connection con, JSONObject inJSON){
		String secret = (String) inJSON.get("secret");
		JSONObject obj=new JSONObject();
		
		obj.put("command", "AUTHENTICATION_FAIL");
		obj.put("info", "the supplied secret is incorrect: " + secret);//change
		
		
		con.writeMsg(obj.toString());
		
		log.debug("Send "+ Command.AUTHENTICATION_FAIL.toString() +" message to " + Settings.socketAddress(con.getSocket()));
		
	}
	
	private void lockRequest(Connection con,JSONObject inJSON){
		String username = (String) inJSON.get("username");
		String secret = (String) inJSON.get("secret");
		JSONObject obj=new JSONObject();
		obj.put("command", "LOCK_REQUEST");
		obj.put("username", username);
		obj.put("secret", secret);
		
		con.writeMsg(obj.toString());
		log.debug("Send "+ Command.LOCK_REQUEST.toString() +" message to " + Settings.socketAddress(con.getSocket()));
	}
	private void lockDenied(Connection con,JSONObject inJSON){
		String username = (String) inJSON.get("username");
		String secret = (String) inJSON.get("secret");
		JSONObject obj=new JSONObject();
		
		obj.put("command", "LOCK_DENIED");
		obj.put("username", username);
		obj.put("secret", secret);
		
		con.writeMsg(obj.toString());
		
		log.debug("Send "+ Command.LOCK_DENIED.toString() +" message to " + Settings.socketAddress(con.getSocket()));
	}
	private void lockAllowed(Connection con,JSONObject inJSON){
		String username = (String) inJSON.get("username");
		String secret = (String) inJSON.get("secret");
		JSONObject obj=new JSONObject();
		
		obj.put("command", "LOCK_ALLOWED");
		obj.put("username", username);
		obj.put("secret", secret);
		obj.put("server", ID);
		
		con.writeMsg(obj.toString());
		log.debug("Send "+ Command.LOCK_ALLOWED.toString() +" message to " + Settings.socketAddress(con.getSocket()));
	}
	

	
	
	private void registerFailed(Connection con,JSONObject inJSON){
		String username = (String) inJSON.get("username");
		JSONObject obj=new JSONObject();
		
		obj.put("command", "REGISTER_FAILED");
		obj.put("info", username + " is already registered with the system");
		
		con.writeMsg(obj.toString());
		log.debug("Send "+ Command.REGISTER_FAILED.toString() +" message to " + Settings.socketAddress(con.getSocket()));
	}
	
	private void registerSuccess(Connection con,JSONObject inJSON){
		String username = (String) inJSON.get("username");
		String secret = (String) inJSON.get("secret");
		JSONObject obj=new JSONObject();
		
		obj.put("command", "REGISTER_SUCCESS");
		obj.put("info", "register success for " +  username);
		Database.put(username, secret);
		con.writeMsg(obj.toString());
		log.debug("Send "+ Command.REGISTER_SUCCESS.toString() +" message to " + Settings.socketAddress(con.getSocket()));
	}
	
	private void activityBroadcast(Connection con,JSONObject inJSON){
		if(supportSSL){
			JSONObject obj = new JSONObject();
	        obj.put("command", "ACTIVITY_BROADCAST");
	        int i = 1;
	        if (!cache.isEmpty()) {
	
	            
	
	            for (Connection c : cache.keySet()) {

	            	
					if ((!c.equals(con))||(loginedUsers.contains(c))) {
		                for(JSONObject o:cache.get(c)){
		                    obj.put("activity" + i, o);
		                    i++;
		                }
					}
	            }
	            i--;

	        } else {
				
				obj.put("activity" + i, inJSON);
	        }

	        if(i!=0){
	        	obj.put("activity_num", i);
	          
    			
				
				if(SSLConnections.contains(con)){
					if((connectionInfo.get(con) != null && connectionInfo.get(con) != 0)||loginedUsers.contains(con)){
	    				con.writeMsg(obj.toString());
	    				log.debug("Send "+ Command.ACTIVITY_BROADCAST.toString() +" message to " + Settings.socketAddress(con.getSocket()));
					}
				}else{
					log.debug("Send "+ Command.ACTIVITY_BROADCAST.toString() +" message to " + Settings.socketAddress(con.getSocket())+" separatly");
					ArrayList<JSONObject> activities = depacking(obj);
					// TODO
					JSONObject activityObj = new JSONObject();
					activityObj.put("command", "ACTIVITY_BROADCAST");
					while(!activities.isEmpty()){
						activityObj.put("activity", activities.remove(0));
						con.writeMsg(activityObj.toString());
					}
					
				}
    			
	    		
	        }
		}else{
			JSONObject activity = (JSONObject) inJSON.get("activity");
			JSONObject obj=new JSONObject();	
			obj.put("command", "ACTIVITY_BROADCAST");
			obj.put("activity", activity);
			
			con.writeMsg(obj.toString());
			log.debug("Send "+ Command.ACTIVITY_BROADCAST.toString() +" message to " + Settings.socketAddress(con.getSocket()));
		}
		
		
	}
	
	private ArrayList<JSONObject> depacking(JSONObject obj){
		ArrayList<JSONObject> activities = new ArrayList<JSONObject>();
		int num_activity=Integer.valueOf(obj.get("activity_num").toString());
		//System.out.println("depacking the activities");
		//System.out.println(num_activity);
		for(int num_add=0;num_add<num_activity;num_add++){
			String activityNumber="activity"+(num_add+1);
			//System.out.println("activityNumber:"+activityNumber);
			JSONObject activityContent = (JSONObject) obj.get(activityNumber);
			//JSONObject new_obj= new JSONObject();
			//System.out.println("activityContent:"+activityContent.toJSONString());
			//new_obj.put("activity",activityContent );
			activities.add(activityContent);
		}
		return activities;
	}
	
    private boolean processServerAnnounce(Connection con, JSONObject obj) {
    	
    	handleRegister();
    	String id = (String) obj.get("id");
    	String hostname = (String) obj.get("hostname");
    	Integer load = Integer.valueOf(obj.get("load").toString());
    	Integer port = Integer.valueOf(obj.get("port").toString());
    	
    	//System.out.println("SSLport: "+SSLport+" supportssl: "+supportssl);
    	if(id == null || hostname == null || load == null || port == null){
			invalidMessage(con,Invalid.INCORRECT_MESSAGE);
			return true;
		}
		
    	if(supportSSL && obj.get("supportSSL")!=null){
    		Integer SSLport = Integer.valueOf(obj.get("SSLport").toString());
        	boolean supportssl= (boolean) obj.get("supportSSL");
    		Integer serverNum = Integer.valueOf(obj.get("server_num").toString());
    		if(serverNum == null){
				invalidMessage(con,Invalid.INCORRECT_MESSAGE);
				return true;
			}
    		serverInfo.put(id,(new ServerInfo(load,hostname,port,serverNum,supportssl,SSLport)));
    	}else{
	    	
	    	serverInfo.put(id,(new ServerInfo(load,hostname,port)));
	    }
        for(Connection c: serverConnections){
        	if(!con.equals(c)){
        		c.writeMsg(obj.toJSONString());
        	}
        }
        return false;
       
        //server_announces.put(id,announce);
        
    }

 
    private void invalidMessage (Connection c,Invalid invalid) {

        JSONObject obj = new JSONObject();
        obj.put("command", "INVALID_MESSAGE");
        obj.put("info", "The invalid massage is "+invalid.toString());
        c.writeMsg(obj.toJSONString());
        log.debug("Send "+ Command.INVALID_MESSAGE.toString() +" message: "+
        invalid.toString()+" to " + Settings.socketAddress(c.getSocket()));
        connectionClosed(c);
    }

    private void redirect(Connection c,String hostname,int portnum) {

        JSONObject obj = new JSONObject();
        obj.put("command", "REDIRECT");
        obj.put("hostname", hostname);
        obj.put("port", portnum);
        obj.put("supportSSL", portnum);
        obj.put("SSLPort", portnum);
        c.writeMsg(obj.toJSONString());
        log.debug("Send "+ Command.REDIRECT.toString() +" message to " + Settings.socketAddress(c.getSocket()));
        connectionClosed(c);
    }
    
    private void redirect(Connection c,String hostname,int portnum,boolean supportSSL,int SSLport) {

        JSONObject obj = new JSONObject();
        obj.put("command", "REDIRECT");
        obj.put("hostname", hostname);
        obj.put("port", portnum);
        obj.put("supportSSL", supportSSL);
        obj.put("SSLPort", SSLport);
        c.writeMsg(obj.toJSONString());
        log.debug("Send "+ Command.REDIRECT.toString() +" message to " + Settings.socketAddress(c.getSocket()));
        connectionClosed(c);
    }
    
    private void serverAnnounce() {

        
    	JSONObject obj = new JSONObject();
    	obj.put("command", "SERVER_ANNOUNCE");
    	obj.put("id", ID);
    	obj.put("load",loginedUsers.size());
    	obj.put("hostname", Settings.getLocalHostname());
    	obj.put("port", Settings.getLocalPort());
    	
    	//new feature
    	if(supportSSL){
    		obj.put("supportSSL", this.supportSSL);
        	obj.put("SSLport", Settings.getLocalSSLPort());
    		obj.put("server_num", serverConnections.size());
    	}
    	
    	
    	for (Connection c : serverConnections) {
    	    c.writeMsg(obj.toJSONString());
    	    log.debug("Send "+ Command.SERVER_ANNOUNCE.toString() +" message to " + Settings.socketAddress(c.getSocket()));
    	}
    }
    
    private void clientChange(ClientOperation CO){
    	JSONObject obj = new JSONObject();
    	obj.put("command", "CLIENT_CHANGE");
    	obj.put("client_operation", CO.toString());
    	    	
    	for (Connection c : serverConnections) {
    		if(SSLConnections.contains(c)){
	    	    c.writeMsg(obj.toJSONString());
	    	    log.debug("Send "+ Command.CLIENT_CHANGE.toString() +" message to " + Settings.socketAddress(c.getSocket()));
    		}
    	}
    }
    
    private void hello(Connection con){
    	JSONObject obj = new JSONObject();
    	obj.put("command", "HELLO");
    	obj.put("supportSSL", supportSSL);
    	con.writeMsg(obj.toJSONString());
        log.debug("Send "+ Command.HELLO.toString() +" message to " + Settings.socketAddress(con.getSocket()));
        
    }
    
    private void reply(Connection con){
    	JSONObject obj = new JSONObject();
    	obj.put("command", "REPLY");
    	obj.put("supportSSL", supportSSL);
    	obj.put("SSLPort", Settings.getLocalSSLPort());
    	con.writeMsg(obj.toJSONString());
        log.debug("Send "+ Command.REPLY.toString() +" message to " + Settings.socketAddress(con.getSocket()));
        
    }
    
    private void finishHello(Connection con){
    	JSONObject obj = new JSONObject();
    	obj.put("command", "FINISH_HELLO");
    	con.writeMsg(obj.toJSONString());
        log.debug("Send "+ Command.FINISH_HELLO.toString() +" message to " + Settings.socketAddress(con.getSocket()));
        
    }
    
    private void handleRegister(){
    	ArrayList<RegisterRequest> iter = (ArrayList<RegisterRequest>) registerRequests.clone();
		for(RegisterRequest r: iter){
			if(r.responseServer <= serverInfo.size()){
				endTime= System.currentTimeMillis();
				
				if(r.responseServer < serverInfo.size() ){
					if((endTime - r.startTime) > 10000){
						registerFailed(r.con,r.inJSON);
						r.con.closeCon();
						connectionClosed(r.con);
						registerRequests.remove(r);
					}
				}else{
					registerSuccess(r.con,r.inJSON);
					registerRequests.remove(r);
				}
				
			}
		}
    }
    
   
    
	
}

class ServerInfo{
	public String hostname;
	public int load,port,serverNum,SSLPort;
	public boolean supportSSL = false;
	
	public ServerInfo( int load,String hostname,int port){
		this.load = load;
		this.hostname = hostname;
		this.port = port;
	}
	public ServerInfo( int load,String hostname,int port,int serverNum,boolean supportSSL, int SSLPort){
		this.load = load;
		this.hostname = hostname;
		this.port = port;
		this.serverNum = serverNum;
		this.SSLPort = SSLPort;
		this.supportSSL = supportSSL;
	}
}

class RegisterRequest{
	public String username,secret;
	public long startTime;
	public int responseServer;
	public Connection con;
	public JSONObject inJSON;
	
	public RegisterRequest(String username, String secret,long startTime,Connection con,JSONObject inJSON){
		this.username = username;
		this.secret = secret;
		this.startTime = startTime;
		this.con = con;
		this.inJSON = inJSON;
		responseServer = 0;
	}
}
