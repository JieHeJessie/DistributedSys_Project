package activitystreamer.server;

import java.io.BufferedReader;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.IOException;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.net.ServerSocket;
import java.net.Socket;
import java.security.KeyManagementException;
import java.security.KeyStore;
import java.security.KeyStoreException;
import java.security.NoSuchAlgorithmException;
import java.security.UnrecoverableKeyException;
import java.security.cert.CertificateException;

import javax.net.ssl.KeyManagerFactory;
import javax.net.ssl.SSLContext;
import javax.net.ssl.SSLServerSocket;
import javax.net.ssl.SSLServerSocketFactory;
import javax.net.ssl.SSLSocket;
import javax.net.ssl.TrustManagerFactory;

import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;

import activitystreamer.util.Settings;

public class SSLListener extends Thread{

	private static final Logger log = LogManager.getLogger();
	private SSLServerSocket sslserversocket=null;
	private SSLServerSocketFactory sslserversocketfactory;
	private boolean term = false;
	private int portnum = 9999;
	private static final String SERVER_KEYSTORE_PWD = "123456";   
    private static final String SERVER_TRUST_KEYSTORE_PWD = "123456";  
	public SSLListener() throws IOException{
		Settings.setLocalSSLPort(Settings.randomPort());
        portnum = Settings.getLocalSSLPort(); // keep our own copy in case it changes later
        System.setProperty("javax.net.ssl.keyStore","files/kserver.keystore");
        System.setProperty("javax.net.ssl.trustStore", "files/tserver.keystore");
		//Password to access the private key from the keystore file
		System.setProperty("javax.net.ssl.keyStorePassword","123456");
		
		
		//Create SSL server socket
		sslserversocketfactory = (SSLServerSocketFactory) SSLServerSocketFactory.getDefault();
		sslserversocket = (SSLServerSocket) sslserversocketfactory.createServerSocket(portnum);
		log.debug("sslserversocket is created");
	
		
          
		start();
	}
	
	@Override
	public void run() {
		  
		log.info("listening for new connections on "+portnum);
		while(!term){
			SSLSocket socket = null;
			try {
				socket = (SSLSocket) sslserversocket.accept();
				ControlSolution.getInstance().incomingSSLConnection(socket);
			} catch (IOException e) {
				log.info("received exception, shutting down");
				term=true;
			}
		}
	}

	public void setTerm(boolean term) {
		this.term = term;
		if(term){
	        try{
	        	sslserversocket.close();

	            } catch (IOException io){
	                log.error("Server Socket close Error");
	            }

	        }
	}

}
