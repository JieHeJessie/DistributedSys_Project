package activitystreamer.client;

/*
 * this is for printing the activity 
 * */

import java.util.ArrayList;

import org.json.simple.JSONObject;

public class PrintActivity extends Thread {
	  //textFrame.addToList((JSONObject) obj.get("activity"));
		private TextFrame textFrame;
		private static PrintActivity printActivity;
		public static ArrayList<JSONObject> receive_obj;
		
		 public static PrintActivity getInstance(TextFrame textFrame){
		        if(printActivity==null){
		        	printActivity = new PrintActivity(textFrame);
		        }
		        return printActivity;
		    }

		    public PrintActivity(TextFrame textFrame){
		    	this.textFrame=textFrame;
		    	receive_obj = new ArrayList<JSONObject>();
		        start();
		    }
		    
		private synchronized void output(){
			
			while(receive_obj.size()==0){
				try {
					wait();
				} catch (InterruptedException e) {
					// TODO Auto-generated catch block
					e.printStackTrace();
				}
			}
			JSONObject activity=receive_obj.remove(0);
			if(activity == null){
				System.out.println("activity is null");
			}
			JSONObject activityContent = (JSONObject) activity.get("activity");
			//System.out.println("activityContent:"+activityContent.toJSONString());
			if(activityContent == null){
				System.out.println("activityContent is null");
			}
			textFrame.setOutputText(activityContent);
			try {
				Thread.sleep(5000);
			} catch (InterruptedException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
		}
		
		public void run(){
			while(true){
				output();
			}
		}

	
		
		
		
}
