package activitystreamer.client;
import java.io.BufferedInputStream;
import java.io.BufferedOutputStream;
/*
 * Description: ClientSolution class used to get user name and secret to finish the process of register or log in
 *              When receive the protocols from server, it needs to take some processes about different responce
 * Major methods:
 * --preprocess(): it used to get the user name and secret, and identify the process of register or login and use 
 *                 JSON object to put the information to server.
 * --run(): it used to read the information from server and identify the command. 
 *          According different command to deal with process by invoking different methods.
 * --redirect(): when the command equals to "REDIRECT", it would invoke this method.
 * --TCPConnection(): build up TCP connection 
 * --invalid(): it used to process the invalid message.
 * --disconnect(): process "LOGOUT" command
 * --closeCon(): close all streams and textframe.
 * 
 */
import java.io.BufferedReader;
import java.io.DataInputStream;
import java.io.DataOutputStream;
import java.io.EOFException;
import java.io.FileInputStream;
import java.io.IOException;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.io.OutputStream;
import java.io.PrintWriter;
import java.net.Socket;
import java.net.UnknownHostException;
import java.security.KeyStore;
import java.util.ArrayList;

import javax.net.ssl.KeyManagerFactory;
import javax.net.ssl.SSLContext;
import javax.net.ssl.SSLSocket;
import javax.net.ssl.TrustManagerFactory;

import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;

import org.json.simple.JSONObject;
import org.json.simple.parser.JSONParser;
import org.json.simple.parser.ParseException;

import activitystreamer.util.Settings;

public class ClientSolution extends Thread {
	private static final Logger log = LogManager.getLogger();
	private static ClientSolution clientSolution;
	private TextFrame textFrame;
	private DataInputStream in;
	private DataOutputStream out;
	private BufferedReader inreader;
	private PrintWriter outwriter;
	private String username;
	private String secret;
	private Socket s = null;
	private boolean connectionFlag = false;
	private boolean redirectFlag = false;
	private boolean closeFlag = false;
	private boolean term = true;
	//initialized command to store 
	enum Command{LOGIN_SUCCESS,LOGIN_FAILED,INVALID_MESSAGE,REDIRECT,REGISTER_SUCCESS,REGISTER_FAILED,ACTIVITY_BROADCAST, REPLY,HELLO};
	private static Command commandState;
	
	//�ж��Ƿ���ssl����
	private static boolean SSLflag=true;
	
	//��������̣߳�ֻ������GUI����ʾ���
	private PrintActivity printActivity;
	
	//key
	private static final String CLIENT_KEY_STORE_PASSWORD       = "123456";  
	private static final String CLIENT_TRUST_KEY_STORE_PASSWORD = "123456";  

	private SSLSocket sslSocket;  

	// this is a singleton object


	public static ClientSolution getInstance(){
		if(clientSolution==null){
			clientSolution = new ClientSolution();
		}
		return clientSolution;
	}

	public ClientSolution(){
		//get username and secret
		secret=Settings.getSecret();
		username=Settings.getUsername();


		//TCP connection
		TCPConnection(); 
		
		//judge if the server support SSL
		if(SSLflag){
			sslCheck();
		}else{
			preprocess();
		}
		//open the GUI
		log.debug("opening the gui");
		textFrame = new TextFrame();
		//justify the process is register or login
		//preprocess();

		// start the client's thread
		start();
	}

	//send hello package
	private void sslCheck(){
		JSONObject obj = new JSONObject();
		obj.put("command", "HELLO");
		obj.put("supportSSL",true);
		outwriter.println(obj.toString());
		outwriter.flush();
	}

	private void preprocess() {
		//build up JSON object
		JSONObject obj=new JSONObject();
		if(secret==null){
			if(username.equals("anonymous")){
				//anonymous
				obj.put("command", "LOGIN");
				obj.put("username", username);                
			}else{
				//register
				obj.put("command", "REGISTER");
				obj.put("username", username);
				//set secret randomly
				secret=Settings.nextSecret();
				Settings.setSecret(secret);

				obj.put("secret", secret);
			}
		}else{
			//login
			obj.put("command", "LOGIN");
			obj.put("username", username);
			obj.put("secret", secret);
		}

		outwriter.println(obj.toString());
		outwriter.flush();

	}

	// called by the gui when the user clicks "send"
	public void sendActivityObject(JSONObject activityObj){
		JSONObject obj=new JSONObject();        
		obj.put("activity", activityObj);
		obj.put("command", "ACTIVITY_MESSAGE");

		if(!username.equals("anonymous")){
			obj.put("secret",secret);
		}
		obj.put("username",username);

		outwriter.println(obj.toString());
		outwriter.flush();
		log.info("send message successfully");

	}

	//store the activities is a list, and show them every 5 seconds
	private void addToList(final JSONObject obj){
		//System.out.println(obj);
		if(SSLflag==true){
			int num_activity=Integer.valueOf(obj.get("activity_num").toString());
			//System.out.println(num_activity);
			for(int num_add=0;num_add<num_activity;num_add++){
				String activityNumber="activity"+(num_add+1);
				//System.out.println("activityNumber:"+activityNumber);
				JSONObject activityContent = (JSONObject) obj.get(activityNumber);
				JSONObject new_obj= new JSONObject();
				//System.out.println("activityContent:"+activityContent.toJSONString());
				new_obj.put("activity",activityContent );
				log.info("store a activity");
				printActivity.receive_obj.add(new_obj);
			}
			
			synchronized(printActivity){
				printActivity.notifyAll();
			}
		}


	}


	// called by the gui when the user clicks disconnect
	public void disconnect(){
		JSONObject obj=new JSONObject();
		obj.put("command", "LOGOUT");
		outwriter.println(obj.toString());
		outwriter.flush();
		log.info("logout");
		term = false;
		closeFlag = true;
		closeCon();

	}


	private void closeCon(){
		if(s!=null) {
			try {
				in.close();
				inreader.close();
				out.close();
				s.close();
			}catch (IOException e){
				log.error("close:"+e.getMessage());
			}
		}
		if(closeFlag){
			
			//System.out.print("Exiting");
			textFrame.setVisible(false);
			System.exit(0);
		}
	}


	// the client's run method, to receive messages
	@Override
	public void run(){

		String data = null;
		JSONObject obj=new JSONObject();
		JSONParser parser = new JSONParser();


		while(term ){
			try {
				if((data = inreader.readLine()) != null){
					//parse data
					log.debug(data);
					try {
						obj = (JSONObject) parser.parse(data);
					} catch (ParseException e) {
						e.printStackTrace();
					}
					//processing
					String command = (String) obj.get("command");
					if(command == null){
						String i="not recevied the commad from server";
						invalid(i);
					}

					commandState = Command.valueOf(command);
					log.info("receive "+commandState.toString()+" message");
					String info = (String) obj.get("info");

					if(info == null && ( commandState != Command.ACTIVITY_BROADCAST && commandState != Command.REDIRECT 
							&& commandState != Command.REPLY)){
						String i="not recevied the info from server";
						invalid(i);                        
					}

					switch(commandState){
					//if the server support ssl, try to connection in ssl
					case REPLY:
						SSLflag=(boolean)obj.get("supportSSL");
						Settings.setRemoteSSLPort((int) Integer.valueOf(obj.get("SSLPort").toString()));
						obj.clear();
						obj.put("command","FINISH_HELLO");
						log.info("send FINISH_HELLO to server");
						outwriter.println(obj.toString());
						closeCon();
						if(SSLflag==true){
							printActivity = PrintActivity.getInstance(textFrame);
							log.info("try to connect to server with SSL");
							SSLConnection();
						}
						//register or login
						preprocess();

						break;
					case LOGIN_SUCCESS:
						log.info(info);
						break;
					case LOGIN_FAILED:
						log.info(info);
						closeFlag = true;
						closeCon();
						break;
					case INVALID_MESSAGE:
						if(SSLflag){
							SSLflag=false;
							//System.out.println("server don't support SSL connection");
							closeCon();
							//System.out.println("try to connect to server in TCP");
							TCPConnection();
							preprocess();
							break;
						}
						log.info(info);
						closeFlag = true;
						closeCon();
						break;
					case REDIRECT:
						//redirectFlag = true;
						String hostname = (String)obj.get("hostname");
						int port = Integer.valueOf(obj.get("port").toString());
						if(hostname == null){
							String i="not recevied the hostname from server";
							invalid(i);                        
						}
						if(port==0){
							String i="not recevied the port number from server";
							invalid(i);                        
						}
						if((boolean) obj.get("supportSSL")){
							redirect(hostname,port,Integer.valueOf(obj.get("SSLPort").toString()));
						}else{
							redirect(hostname,port);
						}
						break;
					case REGISTER_SUCCESS:
						log.info("your secret is " + secret);
						log.info(info);
						preprocess();
						break;
					case REGISTER_FAILED:
						log.info(info);
						closeFlag = true;
						closeCon();
						break;
					case ACTIVITY_BROADCAST:
						log.info("receive a activity message");
						if(SSLflag==true){
							addToList(obj);
							}
						else{
							textFrame.setOutputText((JSONObject) obj.get("activity"));
						}
						break;
					default:
						String i="the recieved command did not exist";
						invalid(i);
						break;

					}
				}
			} catch (NumberFormatException e) {
				closeFlag = true;
				closeCon();
			} catch (IOException e) {
				System.out.println("IOException:"+e);
				System.exit(1);
				//disconnect();
			}
		}

	}


	private void invalid( String i) {

		JSONObject obj=new JSONObject();
		obj.put("command","INVALID_MESSAGE");
		obj.put("info", i);
		outwriter.println(obj.toString());
		closeFlag = true;
		closeCon();
	}


	private void redirect(String hostname, int port) {
		closeCon();
		Settings.setRemotePort(port);
		Settings.setRemoteHostname(hostname);
		if(SSLflag){
			SSLinit();
		}
		else{
			TCPConnection();
		}
		preprocess();
		
		redirectFlag = false;
	}
	
	private void redirect(String hostname, int port,int SSLport) {
		closeCon();
		Settings.setRemotePort(port);
		Settings.setRemoteSSLPort(SSLport);
		Settings.setRemoteHostname(hostname);
		if(SSLflag){
			printActivity = PrintActivity.getInstance(textFrame);
			log.info("try to connect to server with SSL");
			SSLConnection();
		}
		else{
			TCPConnection();
		}
		preprocess();
		
		redirectFlag = false;
	}

	public void TCPConnection() {
		log.info("try to connect to the server");
		try{
			int serverPort = Settings.getRemotePort();
			String serverIP = Settings.getRemoteHostname();
			s = new Socket(serverIP, serverPort);  
			log.info("connection Established");
			in = new DataInputStream( s.getInputStream());
			out =new DataOutputStream( s.getOutputStream());
			inreader = new BufferedReader( new InputStreamReader(in));
			outwriter = new PrintWriter(out, true);
			connectionFlag = true;

		}catch (UnknownHostException e) {
			log.error("Socket:"+e.getMessage());
			System.exit(1);
		}catch (EOFException e){
			log.error("EOF:"+e.getMessage());
			System.exit(1);
		}catch (IOException e){
			log.error("readline:"+e.getMessage());
			System.exit(1);
		}finally {

		}


	}

	//initial ssl
	public void SSLConnection(){
		
		SSLinit();
	}
	
	public void SSLinit() {  
        try {  
            SSLContext ctx = SSLContext.getInstance("SSL");  
  
            KeyManagerFactory kmf = KeyManagerFactory.getInstance("SunX509");  
            TrustManagerFactory tmf = TrustManagerFactory.getInstance("SunX509");  
  
            KeyStore ks = KeyStore.getInstance("JKS");  
            KeyStore tks = KeyStore.getInstance("JKS");  
  
            ks.load(new FileInputStream("files/kclient.keystore"), CLIENT_KEY_STORE_PASSWORD.toCharArray());  
            tks.load(new FileInputStream("files/tclient.keystore"), CLIENT_TRUST_KEY_STORE_PASSWORD.toCharArray());  
  
            kmf.init(ks, CLIENT_KEY_STORE_PASSWORD.toCharArray());  
            tmf.init(tks);  
  
            ctx.init(kmf.getKeyManagers(), tmf.getTrustManagers(), null);  
            log.debug("port:"+Settings.getRemoteSSLPort());
            sslSocket = (SSLSocket) ctx.getSocketFactory().createSocket(Settings.getRemoteHostname(), Settings.getRemoteSSLPort());  
            
            log.info("SSL connection Established");
			in = new DataInputStream( sslSocket.getInputStream());
			out =new DataOutputStream( sslSocket.getOutputStream());
			inreader = new BufferedReader( new InputStreamReader(in));
			outwriter = new PrintWriter(out, true);
			connectionFlag = true;
			
			
        } catch (UnknownHostException e) {
			log.error("Socket:"+e.getMessage());
			System.exit(1);
		}catch (EOFException e){
			log.error("EOF:"+e.getMessage());
			System.exit(1);
		}catch (IOException e){
			log.error("readline:"+e.getMessage());
			System.exit(1);
		}catch(Exception e){
			log.error(e.getMessage());
			System.exit(1);
		}finally {
			
		}
    }
}
